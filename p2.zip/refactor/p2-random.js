/*
    CIT 281 Project 2
    Name: Alex Fort
*/

// Returns a random number between min (inclusive) and max (exclusive)
function getRandomInteger(min, max) {
  return Math.floor(Math.random() * (max - min) + min);
}

//getRandomletter - Returns a random lowercase letter of the enlgish alphabet. Uses getRandomInteger to randomly pick an index number from const alphabet,

function getRandomLetter() {
  const alphabet = "abcdefghijklmnopqrstuvwxyz".split("");
  return alphabet[getRandomInteger(0, alphabet.length)];
}
console.log(getRandomLetter());

//getRandomString - returns a random length string between 10 and 20 characters. Uses a for loop set to loop between 10 and 20 times, in conjuction with the getRandomLetter function to output said random string
function getRandomString(minLength, maxLength) {
    let result = "";
  for (let i = 0; i < getRandomInteger(minLength, maxLength); i++) {
    result += getRandomLetter();
  }
  return result;
}
console.log(getRandomString(10, 20));

//getSortedString - takes the string that is output by getRandomString, and uses Array.from to make it into an array. .sort then sorts this array by aplhabetical order a-z. .join("") turns the result into a string
function getSortedString(string) {
  return Array.from(string).sort().join(""); 
}
console.log(getSortedString(getRandomString(10,20)));
